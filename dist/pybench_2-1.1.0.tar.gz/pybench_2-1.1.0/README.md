# Introduction

Contains a set of benchmarks of Python code. To run the benchmarks, use the following command:

```bash
python -m pybench --benchname=<module> [--rerun true|false] [--output-dir "./data"]
```
